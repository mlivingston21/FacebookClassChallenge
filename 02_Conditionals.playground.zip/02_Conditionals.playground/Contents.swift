import UIKit

//Intention: this plaground test different comparision operators

6<7
18<10

//<=
10<=7 + 0
//>=
2>=1+1

//test the == operator
// use = to set a value to something
// ex) number = 10
//use == to check ig two things are equal
12 == 10 + 2
//test the != operator where ! means neggation
12 != 10 + 2




//check what && does ---> AND(&&)
12 == 10 + 2 // true
12 == 6+6 //true
// & = AND
12 == 10 + 2 && 12 == 6+6
12 == 10 + 2 && 12 == 10 + 10
// the && checks if btoh sides are true, if they are, it retuns true



//checks what ||----> OR
12 == 10 + 2 // true
12 == 6+6 //true
12 == 10 + 2 || 12 == 6+6
12 == 10 + 2 || 12 == 10 + 10
1 + 2 == 1 || 1 + 2 == 2



//declaring if statement

var dogAge = 12
if dogAge < 2 { //checking if dogAGe is less than 2 which is true
    print("You are a puppy🐶") //if the condition check is true, then do this code
} else if dogAge < 6 {
    print("You are an average doggo!")
} else {
    print("You are elderly")
}






