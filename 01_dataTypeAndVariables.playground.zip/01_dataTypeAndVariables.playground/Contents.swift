
import UIKit
/*
var first = "Karlie"
var last = "Kloss"
print ( first + last)

print (last + first)
print(first + " " + last)
print(first + " " + last + " " + first)
print( "I love Karlie")

var integer = 4.0
var double = 5.0

integer*double
*/

var a = 12
var b = 65
var c = 31
var d = 98
var average = (a + b + c + d)/4
print(average)


var integer = 10.25
var double = 20.0
integer*double

var name = "beyonce"
print("Happy Birthday dear \(name)")





 
