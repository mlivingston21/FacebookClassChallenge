import UIKit

 
func walkDog(numberOfDogs : Int) -> Int {
    print("Grab the leash")
    print("Put the leash on the dog")
    print("Open the door")
    print("Go outside")
    print("Do this \(numberOfDogs)")
    let numberOfPoopBags = numberOfDogs *
    3
    return numberOfPoopBags

   
}
var totalCost = walkDog(numberOfDogs: 3) * 3
print(totalCost)



walkDog(numberOfDogs: 3 )


func walkDog(numberOfDogs1 : Int) -> Int {
    let lengthOfWalk = numberOfDogs1 * 15
    return lengthOfWalk
}


/*
func makeCereal() {
    print("get the milk")
    print("get the cereal")
    print("grab a bowl")
    print("put cereal in bowl")
    print ("pour milk into cereal")
}
makeCereal()


func washHair() {
    print("soak in water")
    print("use shampoo")
    print("rinse out")
    print(" wash with conditioner")
    print ("rinse out")
    print("dry hair")
}
washHair()
*/


   
    

