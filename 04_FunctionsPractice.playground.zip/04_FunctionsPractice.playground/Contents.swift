import UIKit

func CookBreakfast() {
    print("go get the ingredients")
  
    print("mix the ingredients together" )
    print("Put the mix into the waffle maker")
}

func CleanBedrooms(numberOfRooms: Int )-> Int {
    print("go grab the vaccum")
    print("dust the furniture")
   
}
func WashtheDishes() {
    print(" go get the soap and dirty dishes" )
}

